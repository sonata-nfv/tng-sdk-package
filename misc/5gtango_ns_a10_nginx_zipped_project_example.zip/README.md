This service contains two VNFs: a load balancer (a10) and a back-end (nginx). The service can be scaled.

THIS SERVICE WILL ONLY WORK ON POP 10.100.32.200, THE IMAGES ARE NOT AVAILABLE ON OTHER POPS.